@extends('buendeal::base')

@section('aimeos_body')
 Terms and conditions page
@stop
