@extends('buendeal::base')

@section('aimeos_body')
 Privacy policy page
@stop
