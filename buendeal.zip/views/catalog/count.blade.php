<?php echo $aibody['catalog/count']; ?>
