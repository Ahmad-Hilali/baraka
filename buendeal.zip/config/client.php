<?php

return [
	'html' => [
		'themes' => [
			'buendeal' => 'buendeal',
		],
	],
	'jsonapi' => [
	],
];
